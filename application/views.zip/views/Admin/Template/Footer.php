<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<footer class="footer">
    <div class="container-fluid clearfix">
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Developed By <b class="text-primary">SwiftSolution - IT</b> <small>(Hamza Nisar)</small></span>
    </div>
</footer>
